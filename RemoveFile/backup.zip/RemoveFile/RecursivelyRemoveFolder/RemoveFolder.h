#pragma once

BOOL RemoveFolder (__in  LPCTSTR pstrPathName);